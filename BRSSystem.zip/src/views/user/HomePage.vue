<template>
    <NavBar></NavBar>
    <div class="mainContent">
        <input type="text" class="searchBook" placeholder="输入关键词，按下Enter进行搜索" @keyup.enter="search" v-model="keyword">

        <h1>猜你喜欢</h1>
        <span>根据你的收藏记录推荐，等你想读、读过的书再多一些，推荐会更加准确</span>

        <BookCard></BookCard>

        <h1>近期热门</h1>
        <h3>新书速递</h3>

        <BookCard class="newBookList"></BookCard>

        <h3>最受关注</h3>

        <BookCard></BookCard>
    </div>
</template>

<script>
import NavBar from '../../components/NavBar.vue'
import Book from '../../components/Book.vue'
import BookCard from '../../components/BookCard.vue'
import axios from 'axios';
import { h, render } from 'vue'

export default {
    components: { NavBar, Book, BookCard },//注册组件
    data() {
        return {
            keyword: "",
        }
    },
    methods: {
        search: function () {
            var keyword = this.keyword
            //转到搜索结果页面
            if (keyword != "") {
                this.$router.push({
                    path: '/book/searchresult',
                    query: {
                        keyword: this.keyword
                    }
                })
                console.log("homepage keyword: " + keyword)
            }
            else {
                alert("请输入关键词")
            }
        },
    },
    mounted() {
        //加载推荐图书列表
        axios.get('http://127.0.0.1:5001/book/guessuserlike').then(res => {
            var newBookList = document.getElementsByClassName("list-group list-group-horizontal")[0]
            for (var i = 0; i < res.data.length; i++) {
                var newLi = document.createElement('li')
                newLi.className = "list-group-item"
                newBookList.appendChild(newLi)
                console.log(res.data[i].img)
                var book = h(Book, { bookimgsrc: res.data[i].img, bookname: res.data[i].title, author: res.data[i].author, bookid: res.data[i].bookid })
                render(book, newLi)
            }
        })
        //加载新书列表
        axios.get('http://127.0.0.1:5001/book/newbooklist').then(res => {
            //获取新书列表
            var newBookList = document.getElementsByClassName("list-group list-group-horizontal")[1]
            //向页面中添加图书
            for (var i = 0; i < res.data.length; i++) {
                var newLi = document.createElement('li')
                newLi.className = "list-group-item"
                newBookList.appendChild(newLi)
                console.log(res.data[i].img)
                var book = h(Book, { bookimgsrc: res.data[i].img, bookname: res.data[i].title, author: res.data[i].author, bookid: res.data[i].bookid })

                //使用render函数把组件挂载到容器上
                //第一个参数是我们使用h函数创造的VNode
                //第二个参数是需要挂载的位置
                render(book, newLi)
            }
        })
        //加载最受关注图书列表
        axios.get('http://127.0.0.1:5001/book/mostPopular').then(res => {
            var newBookList = document.getElementsByClassName("list-group list-group-horizontal")[2]
            for (var i = 0; i < res.data.length; i++) {
                var newLi = document.createElement('li')
                newLi.className = "list-group-item"
                newBookList.appendChild(newLi)
                console.log(res.data[i].img)
                var book = h(Book, { bookimgsrc: res.data[i].img, bookname: res.data[i].title, author: res.data[i].author, bookid: res.data[i].bookid })
                render(book, newLi)
            }
        })
    }
};
</script> 

<style>
.mainContent {
    padding-left: 30px;
    display: inline-block;
    left: 200px;
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    align-items: center;
    overflow-y: scroll;
    scroll-behavior: smooth;
}

.searchBook {
    height: 50px;
    width: 60%;
    border: 1px solid #cccccc;
    margin: 15px auto;
    border-radius: 5px;
    font-size: 20px;
    padding-left: 25px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .2);
}

.newBookList {
    max-width: 80%;
    white-space: nowrap;
}
</style>