<template>
    <div class="main">
        <h1 class="systemName">智能图书推荐系统</h1>

        <div class="input-group flex-nowrap">
            <div class="input-group-prepend">
                <span class="input-group-text" id="addon-wrapping">账号</span>
            </div>
            <input type="text" class="form-control" placeholder="Account" aria-label="Account"
                aria-describedby="addon-wrapping" v-model="account">
        </div>

        <div class="input-group flex-nowrap">
            <div class="input-group-prepend">
                <span class="input-group-text" id="addon-wrapping">密码</span>
            </div>
            <input type="password" class="form-control" placeholder="Password" aria-label="Password"
                aria-describedby="addon-wrapping" v-model="password">
        </div>

        <button type="button" class="btn btn-primary" @click="login">登录</button>

        <p class="tip">
            还没有账号？<a herf="" @click="goRegister">点击注册</a>
        </p>
    </div>
</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            account: "",
            password: ""
        }
    },
    methods: {
        login: function () {
            axios.get('http://localhost:5001/user/login', {
                params: {
                    account: this.account,
                    password: this.password
                }
            }).then(res => {
                if (res.status === 200) {
                    this.$store.commit('setUserData', res.data.name, res.data.account)
                    sessionStorage.setItem("username", JSON.stringify(res.data.name))
                    sessionStorage.setItem("useraccount", JSON.stringify(res.data.account))
                    if (res.data.result === "true") {
                        this.$router.push({
                            path: "/user/homepage",
                        })
                    }
                    else {
                        //输入错误处理
                        alert("账号或密码错误")
                    }
                }
                else {
                    //未正常相应处理
                }
            })
        },
        goRegister: function () {
            this.$router.push({
                path: "/user/register",
            })
        }
    }
}
</script>

<style>
html {
    background-color: #f5f5f5;
}

.systemName {
    margin-bottom: 50px;
}

.main {
    text-align: center;
    align-items: center;
    max-width: 400px;
    max-height: fit-content;
    margin: auto;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    justify-content: center;
}

.btn-primary {
    width: 400px;
    margin-top: 30px;
}

.tip {
    margin-top: 10px;
}
</style>