<template>
    <NavBar></NavBar>
    <div class="mainContent">
        <input type="text" class="searchBook" placeholder="在我的收藏中搜索" @keyup.enter="search" v-model="keyword">

        <h1>我的收藏</h1>

        <BookCard></BookCard>
    </div>
</template>

<script>
import NavBar from '../../components/NavBar.vue'
import Book from '../../components/Book.vue'
import BookCard from '../../components/BookCard.vue'

export default {
    components: { NavBar, Book, BookCard },//注册组件
    data() {
        return {
            keyword: ""
        }
    },
    methods: {
        search: function () {
            var keyword = this.keyword
            //转到搜索结果页面
            if (keyword != "") {
                this.$router.push({
                    path: "/book/searchresult",
                })
            }
            else {
                alert("请输入关键词")
            }
        }
    }
};
</script> 

<style>
.mainContent {
    padding-left: 30px;
    display: inline-block;
    left: 200px;
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    align-items: center;
    overflow-y: scroll;
    scroll-behavior: smooth;
}
</style>