<template>
    <NavBar></NavBar>
    <div class="mainContent">

        <p>用户名: {{ this.$store.state.username }}</p>
        <p>账号: {{ this.$store.state.useraccount }}</p>
        <button type="button" class="btn btn-outline-primary">修改个人信息</button>

    </div>
</template>

<script>
import NavBar from '../../components/NavBar.vue'

export default{
    components: { NavBar },
    data(){
        return {
            username: 'xxx',
            useraccount: 'xxx'
        }
    }
}
</script> 

<style>
.mainContent {
    padding-left: 30px;
    display: inline-block;
    left: 200px;
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    align-items: center;
    overflow-y: scroll;
    scroll-behavior: smooth;
}
</style>