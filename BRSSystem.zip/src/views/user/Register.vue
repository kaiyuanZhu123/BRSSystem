<template>
    <div class="main">
        <div class="input-group flex-nowrap">
            <div class="input-group-prepend">
                <span class="input-group-text" id="addon-wrapping">用户名</span>
            </div>
            <input type="text" class="form-control" aria-describedby="addon-wrapping" v-model="username">
        </div>

        <div class="input-group flex-nowrap">
            <div class="input-group-prepend">
                <span class="input-group-text" id="addon-wrapping">密码</span>
            </div>
            <input type="password" class="form-control" aria-describedby="addon-wrapping" v-model="password">
        </div>

        <div class="input-group flex-nowrap">
            <div class="input-group-prepend">
                <span class="input-group-text" id="addon-wrapping">重复密码</span>
            </div>
            <input type="password" class="form-control" aria-describedby="addon-wrapping" v-model="repeatpassword">
        </div>

        <button type="button" class="btn btn-primary" @click="register">注册</button>

        <p class="tip">
            已有账号？<a @click="goLogin">去登陆</a>
        </p>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            username: "",
            password: "",
            repeatpassword: ""
        }
    },
    methods: {
        goLogin: function () {
            this.$router.push({
                path: "/user/login",
            })
        },
        register: function () {
            var username = this.username;
            var password = this.password;
            var repeatpassword = this.password;
            alert("username: " + username + "\n" +
                "password: " + password + "\n" +
                "repeatpassword: " + repeatpassword)
            if (password == repeatpassword) {
                axios.post('http://localhost:5001/user/register', {
                    params: {
                        username: this.username,
                        password: this.password
                    }
                }).then(res => {
                    alert(res.data.result)
                    if(res.data.result == "success"){
                        alert("注册成功！" + "\n" + "用户账号为: " + res.data.account)
                    }
                    else{
                        //注册失败提示
                    }
                })
            }
            else {
                //提示两次输入密码不一致
                alert("两次输入密码不一致，请重新输入")
            }
        }
    }
}
</script>

<style scoped>
html {
    background-color: #f5f5f5;
}

.title {
    margin-bottom: 50px;
}

.main {
    text-align: center;
    align-items: center;
    max-width: 400px;
    max-height: fit-content;
    margin: auto;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    justify-content: center;
}

.btn-primary {
    width: 400px;
    margin-top: 30px;
}

.tip {
    margin-top: 10px;
}
</style>