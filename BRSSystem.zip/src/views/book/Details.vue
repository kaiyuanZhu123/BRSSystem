<template>
    <NavBar></NavBar>
    <div class="mainContent">
        <div class="bookInfo">
            <img src="../../components/图书封面样例.jpg" class="bookImg" alt="...">
            <div class="bookDetails" bookid="">
                <p>书名《XXXXX》</p>
                <p>作者XXXXX</p>
                <p>出版社XXXXX</p>
                <p>分类XXXXX</p>
                <p>发行日期XXXX-XX-XX</p>
                <p>大众评分XX.X</p>
                <p>我的评分XX.X</p>
                <p>收藏</p>
            </div>
        </div>

        <div class="commentArea">
            <input type="text">
            <button>发布</button>
        </div>

        <div class="otherComment">
            <h3>评论（共XXX条）</h3>
            <ul>
                <li>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import NavBar from '../../components/NavBar.vue'
import Comment from '../../components/Comment.vue'

export default {
    props: ['bookid'],
    components: { NavBar, Comment },//注册组件
    // data(){
    //     return {
    //         bookid: ''
    //     }
    // },
    mounted(){
        console.log(this.$route.query.bookid)
    }
};
</script> 

<style>
.mainContent {
    padding-left: 30px;
    display: inline-block;
    left: 200px;
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    align-items: center;
    overflow-y: scroll;
    scroll-behavior: smooth;
}

.bookInfo {
    text-align: left;
    position: relative;
    width: 100%;
    height: 320px;
}

.bookImg {
    display: inline-block;
    width: 150px;
    height: 200px;
    position: absolute;
    top: 50%;
    transform: translate(0,-50%);
}

.bookDetails {
    display: inline-block;
    position: absolute;
    height: 100%;
    left: 200px;
}

ul {
    list-style-type: none;
    margin-left: 0;
    padding-left: 0;
}
</style>