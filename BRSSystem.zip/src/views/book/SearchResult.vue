<template>
    <NavBar></NavBar>
    <div class="mainContent">
        <input type="text" class="searchBook" placeholder="输入关键词，按下Enter进行搜索" @keyup.enter="search" v-model="keyword">

        <h1>搜索{{ beforeKeyword }}</h1>

        <BookCard></BookCard>

        <h3>相似图书</h3>

        <BookCard></BookCard>
    </div>
</template>

<script>
import NavBar from '../../components/NavBar.vue'
import Book from '../../components/Book.vue'
import BookCard from '../../components/BookCard.vue'
import axios from 'axios';
import { h, render } from 'vue'

export default {
    components: { NavBar, Book, BookCard },
    data() {
        return {
            keyword: "",
            beforeKeyword: ""
        }
    },
    methods: {
        search: function () {
            var keyword = this.keyword
            //转到搜索结果页面
            if (keyword != "") {
                this.$router.push({
                    path: '/book/searchresult',
                    query: {
                        keyword: keyword
                    }
                })
            }
            else {
                alert("请输入关键词")
            }
        },
    },
    mounted() {
        this.beforeKeyword = this.$route.query.keyword
        console.log("searchResult beforekey: " + this.beforeKeyword)
        // 生成搜索结果列表
        axios.get('http://127.0.0.1:5001/book/searchbook', {
            params: {
                keyword: this.beforeKeyword
            }
        }
        ).then(res => {
            var booklist = document.getElementsByClassName("list-group list-group-horizontal")[0]
            for (var i = 0; i < res.data.length; i++) {
                var newLi = document.createElement('li')
                newLi.className = "list-group-item"
                booklist.appendChild(newLi)
                console.log(res.data[i].img)
                var book = h(Book, { bookimgsrc: res.data[i].img, bookname: res.data[i].title, author: res.data[i].author, bookid: res.data[i].bookid })
                render(book, newLi)
            }
        })
        // 生成相似图书列表
        axios.get('http://127.0.0.1:5001/book/similarbook'
        ).then(res => {
            var booklist = document.getElementsByClassName("list-group list-group-horizontal")[1]
            for (var i = 0; i < res.data.length; i++) {
                var newLi = document.createElement('li')
                newLi.className = "list-group-item"
                booklist.appendChild(newLi)
                console.log(res.data[i].img)
                var book = h(Book, { bookimgsrc: res.data[i].img, bookname: res.data[i].title, author: res.data[i].author, bookid: res.data[i].bookid })
                render(book, newLi)
            }
        })
    },
    watch: {
        $route(to, from) {
            window.location.reload(); //监测到路由发生跳转时刷新一次页面
        },
    },

};
</script>

<style>
.mainContent {
    padding-left: 30px;
    display: inline-block;
    left: 200px;
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    align-items: center;
    overflow-y: scroll;
    scroll-behavior: smooth;
}

.searchBook {
    height: 50px;
    width: 60%;
    border: 1px solid #cccccc;
    margin: 15px auto;
    border-radius: 5px;
    font-size: 20px;
    padding-left: 25px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .2);
}
</style>