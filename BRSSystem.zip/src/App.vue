
<script>

</script>


<template>
  <!-- 根据路由不断切换内容 -->
  <RouterView />
</template>


<style scoped>

</style>

