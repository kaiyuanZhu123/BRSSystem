import api from "./api"

const user = {
    getUsers(){
       return  api.get('user/list')
    },

    login(){

    },

    register(data){
        return api.post('user/reg',data)
    }
}
export default user