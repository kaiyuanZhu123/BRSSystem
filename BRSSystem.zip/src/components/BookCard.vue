<template>
    <ul class="list-group list-group-horizontal">
        <!-- <li class="list-group-item">
            <Book></Book>
        </li>
        <li class="list-group-item">
            <Book></Book>
        </li>
        <li class="list-group-item">
            <Book></Book>
        </li> -->
    </ul>
</template>

<script>
import Book from './Book.vue'

export default {
    components: { Book }//注册组件
};
</script>

<style>
</style>