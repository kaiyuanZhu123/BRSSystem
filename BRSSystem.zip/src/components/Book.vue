<template>
    <div class="card" @click="goDetils" bookid="">
        <img src={{bookimgsrc}} class="img" alt="...">
        <div class="body">
            <p class="title">{{ bookname }}</p>
            <p class="text">{{ author }} 主编</p>
        </div>
    </div>
</template>

<script>
export default {
    props: ['bookimgsrc', 'bookname', 'author', 'bookid'],
    methods: {
        goDetils: function () {
            console.log("goDetails: " + this.bookid)
            this.$router.push({
                path: '/book/details',
                // query: {
                //     bookid: this.bookid
                // }
            })
        }
    }
}
</script>

<style>
.card {
    height: 180px;
    max-height: 180px;
    width: 100px;
    text-align: center;
    padding: 0 0 0 0;
    margin: 0 0;
}

.img {
    height: 132px;
    width: 100%;
    max-width: 100%;
    max-height: 60%;
    padding: 0 0 0 0;
    margin: 0 0;
    overflow: hidden;
    object-fit: contain;
}

.body {
    width: 100%;
    height: 48px;
    max-height: 40%;
    padding: 0 0 0 0;
    margin: 0 0;
}

.title {
    width: 100%;
    height: 24px;
    font-size: 12px;
    padding: 0 0;
    margin: 0 0;
    line-height: 24px;
}

.text {
    width: 100%;
    height: 24px;
    font-size: 12px;
    padding: 0 0;
    margin: 0 0;
    line-height: 24px;
}
</style>