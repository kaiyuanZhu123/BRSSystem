<template>
    <div class="aComment">
        <h5 class="username">用户XXXX</h5>
        <p class="comment">一些评论</p>
    </div>
</template>

<script>

</script>

<style>
.aComment {
    width: 80%;
    background-color: white;
}
</style>