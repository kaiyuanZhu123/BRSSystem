<template>
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="#">Hi!{{ this.$store.state.username }}</div>
        <div class="sidebar-sticky pt-3">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" @click="goHomePage">
                        首页
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" @click="goSelfPage">
                        个人主页
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" @click="goMyCollection">
                        我的收藏
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        历史书评
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        搜索记录
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" @click="exit">
                        退出
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</template>

<script>
export default{
    methods: {
        exit: function(){
            this.$router.push({
                path: '/'
            })
        },
        goHomePage: function(){
            this.$router.push({
                path: '/user/homepage'
            })
        },
        goSelfPage: function(){
            this.$router.push({
                path: '/user/selfpage'
            })
        },
        goMyCollection: function(){
            this.$router.push({
                path: '/user/mycollection'
            })
        },
    }
}
</script>

<style scoped>
.navbar-brand {
    width: 100%;
    padding-top: .75rem;
    padding-bottom: .75rem;
    font-size: 1rem;
    background-color: rgba(0, 0, 0, .25);
    box-shadow: inset -1px 0 0 rgba(0, 0, 0, .25);
}

/*
 * Sidebar
 */

.sidebar {
    display: inline-block;
    width: 200px;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    padding: 0 0 0;
}

@media (max-width: 767.98px) {
    .sidebar {
        top: 5rem;
    }
}

.sidebar-sticky {
    position: relative;
    top: 0;
    height: calc(100vh - 48px);
    padding-top: .5rem;
    overflow-x: hidden;
    overflow-y: auto;
    background-color: #28a745;
}

@supports ((position: -webkit-sticky) or (position: sticky)) {
    .sidebar-sticky {
        position: -webkit-sticky;
        position: sticky;
    }
}

.sidebar .nav-link {
    font-weight: 500;
    color: #333;
}

.sidebar .nav-link .feather {
    margin-right: 4px;
    color: #999;
}

.sidebar .nav-link.active {
    color: #007bff;
}

.sidebar .nav-link:hover .feather,
.sidebar .nav-link.active .feather {
    color: inherit;
}
</style>