import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { createStore } from 'vuex'

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import 'jquery/dist/jquery.slim.min.js'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'

const store = createStore({
    state() {
        return {
            useraccount: JSON.parse(sessionStorage.getItem("useraccount")) || [],
            username: JSON.parse(sessionStorage.getItem("username")) || []
        }
    },
    mutations: {
        setUserData(state, name, account){
            state.username = name
            sessionStorage.setItem("username", JSON.stringify(name))
            state.useraccount = account
            sessionStorage.setItem("useraccount", JSON.stringify(account))
        },
        getUserName(state){
            return JSON.parse(sessionStorage.getItem("username"))
        }
    }
})

const app = createApp(App)

app.use(ElementPlus)

app.use(router)

app.use(store)

app.mount('#app')

export default {store}
