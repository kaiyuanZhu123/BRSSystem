import { createRouter, createWebHistory } from 'vue-router'

import Login from '../views/user/Login.vue'
import Register from '../views/user/Register.vue'
import HomePage from '../views/user/HomePage.vue'
import SelfPage from '../views/user/SelfPage.vue'
import MyCollection from '../views/user/MyCollection.vue'
import SearchResult from '../views/book/SearchResult.vue'
import Details from '../views/book/Details.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: Login
    },
    {
      path: '/user/login',
      name: 'login',
      component: Login
    },
    {
      path: '/user/register',
      name: 'register',
      component: Register
    },
    {
      path: '/user/homepage',
      name: 'homepage',
      component: HomePage
    },
    {
      path: '/user/selfpage',
      name: 'selfpage',
      component: SelfPage
    },
    {
      path: '/user/mycollection',
      name: 'mycollection',
      component: MyCollection
    },
    {
      path: '/book/searchresult',
      name: 'searchresult',
      component: SearchResult
    },
    {
      path: '/book/details',
      name: 'details',
      component: Details
    },
  ]
})

export default router
