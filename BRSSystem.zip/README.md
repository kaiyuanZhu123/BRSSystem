# garbage

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
##  核心知识点
- Node.js   NPM（包管理工具）
- Vue初始化 
- 项目结构
- .vue  html  css js
- 数据渲染  {{}}、
- 属性绑定 v-bind:
- 事件绑定 v-on:   @
- 双向数据绑定  v-model
- 条件指令  v-if   v-else  
- 循环指令   v-for
- 组件：.vue    import     components：注册   使用
-----------------------------------------------------------
- 路由 页面跳转 传递参数
- 生命周期函数
- 数据请求<封装>
- bootstarp   echarts     
    npm install  框架  --save
    main.js   配置
    .vue     直接复制代码使用

- 模板项目
--------------------------------------------------------------
跨越的解决：后端解决跨域问题
前端调试：学会使用谷歌、火狐浏览的的控制台
-----------------------------------------------------------
npm run bulid  ====> dist
              打包静态资源包   nignx：www  部署
              代码压缩
              代码混淆
              图片压缩
              
